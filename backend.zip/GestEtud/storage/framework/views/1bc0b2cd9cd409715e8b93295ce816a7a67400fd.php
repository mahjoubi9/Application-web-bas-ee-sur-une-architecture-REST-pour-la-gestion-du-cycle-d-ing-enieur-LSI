<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <title>ADMIN</title>
</head>
<body>
    <h1>Cycle d'ingénieur LSI</h1>
    
    <div class="container">
        <br>
        <?php echo $__env->yieldContent('content'); ?>;
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\Gestion_LSI\GestEtud\resources\views/admin/layout.blade.php ENDPATH**/ ?>