


<?php $__env->startSection('title' , 'About Us | ' . config('app.name')); ?>


<?php $__env->startSection('content'); ?>

<p>You can do it &hearts;</p>
<p>UBO</p>

&middot; <a href="<?php echo e(route('welcome')); ?>">About Us</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Gestion_LSI\GestEtud\resources\views/about.blade.php ENDPATH**/ ?>